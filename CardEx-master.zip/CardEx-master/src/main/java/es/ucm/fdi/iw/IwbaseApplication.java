package es.ucm.fdi.iw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IwbaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(IwbaseApplication.class, args);
	}
}
